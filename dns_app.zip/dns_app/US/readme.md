US: User server
