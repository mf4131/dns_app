FS: Fibonacci Server
