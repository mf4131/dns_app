HW:  NYU DCN Spring 2022 Lab3
